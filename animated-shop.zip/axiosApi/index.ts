export { default as tesloApi } from "./tesloApi";
