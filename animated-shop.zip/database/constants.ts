export const SHOP_CONSTANTS = {
    validGenders: ["men", "women", "kid", "unisex"],
}